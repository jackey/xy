<?php

// This file is used only on first installation!

$options = array();
$options['subscribe_label'] = 'Subscribe our newsletter';
$options['subscribe'] = 0;
$options['confirmation'] = 0;
$options['welcome'] = 0;
$options['delete'] = 0;

