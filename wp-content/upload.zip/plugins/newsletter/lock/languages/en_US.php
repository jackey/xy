<?php

// This file is used only on first installation!

$options = array();
$options['ids'] = '';
$options['url'] = '';
$options['message'] = '<p>Subscribe to our newsletter and get access to the full article.</p>[subscription_form]';
$options['enabled'] = 0;