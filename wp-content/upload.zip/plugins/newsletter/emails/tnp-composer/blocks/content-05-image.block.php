<!-- ONE COLUMN SECTION -->
<table border="0" cellpadding="0" cellspacing="0" width="100%" class="tnpc-row" data-id="content-05">
    <tr>
        <td bgcolor="#ffffff" align="center" style="padding: 0; font-family: Helvetica, Arial, sans-serif;" class="section-padding edit-block">
            <div class="tnpc-row-edit" data-type="image">
                <a href="#" target="_blank">
                    <img src="https://unsplash.it/800/300?image=998" width="800" border="0" alt="Insert alt text here" style="max-width: 100%!important; width: 800px!important; height: auto!important;display: block; color: #666666;  font-family: Helvetica, arial, sans-serif; font-size: 16px;" class="img-max">
                </a>
            </div>
        </td>
    </tr>
</table>