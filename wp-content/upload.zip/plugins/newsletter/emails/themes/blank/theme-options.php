<?php
if (!defined('ABSPATH')) exit;
?>
<table class="form-table">
    <tr>
        <th>Disable social links</th>
        <td><?php $controls->checkbox('theme_social_disable', ''); ?></td>
    </tr>
</table>